
export interface GameData {
  id: string;
  time: Date;
  type: string;
  winner: string;
}